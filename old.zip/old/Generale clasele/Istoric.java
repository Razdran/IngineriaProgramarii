import java.util.Vector;

public class Istoric {

  public Istoric Instanta;

  public List<Comanda> comenzi;

    public Vector  myComanda;
    /**
   * 
   * @element-type Comanda
   */
  public Vector  myComanda;
    /**
   * 
   * @element-type Utilizator
   */
  public Vector  myUtilizator;

  private void Istoric() {
  }

  public List<Comanda> getIstoric(Integer id_utilizator) {
  return null;
  }

  public void addComanda(Comanda comanda) {
  }

}