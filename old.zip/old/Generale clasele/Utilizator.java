public class Utilizator {

  private Integer id_utilizator;

  private String nume;

  private String adresa;

    public Istoric myIstoric;

  public Integer get_userID() {
  return null;
  }

  public String get_nume() {
  return null;
  }

  public String get_adresa() {
  return null;
  }

  public void set_adresa(String adresa) {
  }

}