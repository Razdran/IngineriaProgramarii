import java.util.Vector;

public class Comanda {

  private Integer id_comanda;

  private String status;

  private List<String> continut;

  private static Integer nextId;

    public Vector  myIstoric;
    public Vector  myIstoric;

  public Integer get_id() {
  return null;
  }

  public String get_status() {
  return null;
  }

  public List<String> get_continut() {
  return null;
  }

  public void set_id(Integer id) {
  }

}